public class InstaPost {
    private int totalMention;
    private String email;
    private String username;

    public void Instapost(){

    }
    public void printinfo(){

    }
    public void login(String email, String username){

    }
    public void post(String caption){

    }
}